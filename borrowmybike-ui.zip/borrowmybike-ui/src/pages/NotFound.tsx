export default function NotFound() {
  return (
    <div>
      <h1>Not Found</h1>
      <p>Wrong URL.</p>
    </div>
  );
}
